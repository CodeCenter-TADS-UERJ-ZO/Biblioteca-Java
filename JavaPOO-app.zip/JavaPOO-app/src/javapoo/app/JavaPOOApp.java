/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javapoo.app;

/**
 *
 * @author uezo
 */
import java.util.Scanner;
public class JavaPOOApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        System.out.println("Entre com um número  ....: ");
        int numero =(Integer.parseInt(sc.nextLine()));
        
        if (numero % 3 == 0 && numero % 4 == 0)
        {
            System.out.println("O número " + numero + " é múltiplo de 3 e 4 ao mesmo tempo\n" );
        }else {
            System.out.println("O número não é multiplo.");
        }
        
    }
    
}
